import React, { useState, useEffect } from 'react';
import { AlertTriangle, Lock, Mail, Eye, EyeOff, CloudLightning, Waves, Wind } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';

const LoginPage = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState(''); // Added state for full name
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false); // Toggle between login and register
  const [alertVisible, setAlertVisible] = useState(false); // State for alert visibility
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (location.state && location.state.message) {
      setAlertVisible(true);
      setTimeout(() => {
        setAlertVisible(false);
      }, 3000);
    }
  }, [location.state]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (isRegistering) {
        // Handle user registration
        const response = await axios.post('http://localhost:5000/auth/register', {
          email,
          password,
          fullName, // Send full name to the backend
        });

        if (response.status === 201) {
          setAlertVisible(true);
          setTimeout(() => navigate('/login', { state: { message: 'Registration successful!' } }), 3000);
        }
      } else {
        // Handle user login
        const response = await axios.post('http://localhost:5000/auth/login', { email, password });

        if (response.status === 200) {
          const { token, fullName } = response.data;
          const userData = {
            username: fullName,
            email,
            token
          };
          onLogin(true, userData);
          navigate('/dashboard');
        }
      }
    } catch (error) {
      if (error.response) {
        setError(error.response.data.message || 'An error occurred. Please try again.');
      } else if (error.request) {
        setError('No response from server. Please try again.');
      } else {
        setError('An unexpected error occurred.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 py-12 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute left-1/4 top-1/4 floating-icon transition-transform duration-1000 ease-in-out">
          <CloudLightning className="h-16 w-16 text-yellow-400 opacity-30" />
        </div>
        <div className="absolute right-1/4 bottom-1/4 floating-icon transition-transform duration-1000 ease-in-out">
          <Waves className="h-16 w-16 text-blue-400 opacity-30" />
        </div>
        <div className="absolute left-1/3 bottom-1/3 floating-icon transition-transform duration-1000 ease-in-out">
          <Wind className="h-16 w-16 text-gray-400 opacity-30" />
        </div>
      </div>
      <div className="max-w-md w-full space-y-8 bg-white bg-opacity-10 backdrop-filter backdrop-blur-lg p-10 rounded-xl shadow-2xl relative z-10">
        <div>
          <div className="flex justify-center">
            <AlertTriangle className="h-20 w-20 text-red-500 animate-pulse" />
          </div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-white">
            {isRegistering ? 'Register' : 'Sign In'}
          </h2>
          <p className="mt-2 text-center text-sm text-gray-300">
            {isRegistering ? 'Create a new account' : 'Access the Aggregation Software'}
          </p>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {isRegistering && (
            <div>
              <label htmlFor="fullName" className="sr-only">Full Name</label>
              <input
                id="fullName"
                name="fullName"
                type="text"
                autoComplete="name"
                required
                className="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-red-500 focus:border-red-500 focus:z-10 sm:text-sm bg-white bg-opacity-80"
                placeholder="Full Name"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
              />
            </div>
          )}
          <div>
            <label htmlFor="email" className="sr-only">Email address</label>
            <input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              required
              className="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-red-500 focus:border-red-500 focus:z-10 sm:text-sm bg-white bg-opacity-80"
              placeholder="Email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="password" className="sr-only">Password</label>
            <input
              id="password"
              name="password"
              type={showPassword ? "text" : "password"}
              autoComplete="current-password"
              required
              className="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-red-500 focus:border-red-500 focus:z-10 sm:text-sm bg-white bg-opacity-80"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <div>
            <button
              type="submit"
              className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              disabled={loading}
            >
              {loading ? 'Processing...' : isRegistering ? 'Register' : 'Sign In'}
            </button>
          </div>
        </form>
        <div className="mt-4 text-center text-gray-300">
          <p>
            {isRegistering
              ? 'Already have an account? '
              : 'New user? '}
            <span
              className="text-red-400 cursor-pointer"
              onClick={() => setIsRegistering(!isRegistering)}
            >
              {isRegistering ? 'Sign in here' : 'Register here'}
            </span>
          </p>
        </div>
      </div>
      {alertVisible && (
        <div className="fixed bottom-5 right-5 bg-blue-500 text-white p-4 rounded-lg shadow-lg">
          <span>Registration successful! Please log in.</span>
        </div>
      )}
    </div>
  );
};

export default LoginPage;
