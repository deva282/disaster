import React from 'react';
import { Search, ChevronDown } from 'lucide-react';

const disasterTypes = {
  earthquake: { icon: '🌋', color: 'bg-yellow-500' },
  flood: { icon: '🌊', color: 'bg-blue-500' },
  cyclone: { icon: '🌀', color: 'bg-cyan-500' },
  drought: { icon: '☀️', color: 'bg-orange-500' },
  tsunami: { icon: '🌊', color: 'bg-blue-700' },
  landslide: { icon: '⛰️', color: 'bg-brown-500' },
  volcanic: { icon: '🌋', color: 'bg-red-700' },
  wildfire: { icon: '🔥', color: 'bg-red-500' },
  storm: { icon: '⛈️', color: 'bg-gray-500' },
  tornado: { icon: '🌪️', color: 'bg-purple-500' },
  heatwave: { icon: '🌡️', color: 'bg-red-600' },
  blizzard: { icon: '❄️', color: 'bg-blue-200' },
  avalanche: { icon: '🏔️', color: 'bg-gray-200' }
};

const severityColors = {
  low: 'bg-green-500',
  moderate: 'bg-yellow-500',
  severe: 'bg-red-500',
  critical: 'bg-purple-500',
};

const indianStates = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat', 'Haryana',
  'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur',
  'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana',
  'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal', 'Delhi', 'Jammu and Kashmir', 'Ladakh',
  'Puducherry', 'Andaman and Nicobar Islands', 'Chandigarh', 'Dadra and Nagar Haveli and Daman and Diu',
  'Lakshadweep',
];

export default function SearchFilters({ searchTerm, setSearchTerm, filterType, setFilterType, filterSeverity, setFilterSeverity, filterState, setFilterState }) {
  return (
    <div className="p-6 bg-white rounded-lg shadow-lg ">
      <div className="relative mb-4">
        <input
          type="text"
          placeholder="Search locations..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full p-3 pl-10 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 placeholder-gray-400"
        />
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="relative">
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="w-full p-3 pr-10 border border-gray-300 rounded-md appearance-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white"
          >
            <option value="">All Types</option>
            {Object.entries(disasterTypes).map(([type, { icon }]) => (
              <option key={type} value={type}>
                {icon} {type.charAt(0).toUpperCase() + type.slice(1)}
              </option>
            ))}
          </select>
          <ChevronDown className="pointer-events-none absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        </div>
        <div className="relative">
          <select
            value={filterSeverity}
            onChange={(e) => setFilterSeverity(e.target.value)}
            className="w-full p-3 pr-10 border border-gray-300 rounded-md appearance-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white"
          >
            <option value="">All Severities</option>
            {Object.entries(severityColors).map(([severity, color]) => (
              <option key={severity} value={severity} className="flex items-center">
                <span className={`inline-block w-3 h-3 rounded-full ${color} mr-2`}></span>
                {severity.charAt(0).toUpperCase() + severity.slice(1)}
              </option>
            ))}
          </select>
          <ChevronDown className="pointer-events-none absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        </div>
        <div className="relative">
          <select
            value={filterState}
            onChange={(e) => setFilterState(e.target.value)}
            className="w-full p-3 pr-10 border border-gray-300 rounded-md appearance-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white"
          >
            <option value="">All States</option>
            {indianStates.map(state => (
              <option key={state} value={state}>{state}</option>
            ))}
          </select>
          <ChevronDown className="pointer-events-none absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        </div>
      </div>
    </div>
  );
}