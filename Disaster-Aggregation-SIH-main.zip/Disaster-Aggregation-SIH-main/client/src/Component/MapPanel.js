import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { CheckCircle, AlertCircle, Mail } from 'lucide-react';
import io from 'socket.io-client'; // Import Socket.IO client

const customIcon = new L.Icon({
  iconUrl: '/img/custom-marker-icon.png',
  iconSize: [32, 32],
  iconAnchor: [16, 32],
  popupAnchor: [0, -32],
});

// Component to update the map view based on selected alert
const MapViewUpdater = ({ selectedAlert, alerts }) => {
  const map = useMap();

  useEffect(() => {
    if (selectedAlert) {
      const alert = alerts.find(a => a.id === selectedAlert);
      if (alert) {
        map.flyTo([alert.lat, alert.lng], 11, { animate: true, duration: 2.0 }); // Zoom to the selected alert's location with animation
      }
    }
  }, [selectedAlert, alerts, map]);

  return null;
};



const severityColors = {
  low: 'bg-green-500',
  moderate: 'bg-yellow-500',
  severe: 'bg-red-500',
  critical: 'bg-purple-500',
};

const CustomToast = ({ type, message }) => (
  <div className="flex items-center bg-white border-l-4 border-blue-500 py-2 px-3 shadow-md mb-2 rounded-r">
    {type === 'success' ? (
      <CheckCircle className="text-green-500 mr-2" />
    ) : (
      <AlertCircle className="text-red-500 mr-2" />
    )}
    <div className="text-sm font-medium text-gray-900">{message}</div>
  </div>
);

const sendEmail = async (alert) => {
  try {
    const response = await fetch('http://localhost:5000/api/email', { // Updated URL
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        type: alert.type,
        location: alert.location,
        severity: alert.severity,
        affected: alert.affected,
      }),
    });

    if (response.ok) {
      toast.success(<CustomToast type="success" message="Email sent successfully!" />);
      return true;
    } else {
      toast.error(<CustomToast type="error" message="Failed to send email." />);
      return false;
    }
  } catch (error) {
    console.error('Error sending email:', error);
    toast.error(<CustomToast type="error" message="Error sending email." />);
    return false;
  }
};

const NotifyButton = ({ alert }) => {
  const [isSending, setIsSending] = useState(false);
  const [isSent, setIsSent] = useState(false);

  const handleSendEmail = async () => {
    setIsSending(true);
    const success = await sendEmail(alert);
    setIsSending(false);
    if (success) {
      setIsSent(true);
    }
  };

  return (
    <button
      onClick={handleSendEmail}
      disabled={isSending || isSent}
      className={`mt-2 px-4 py-2 rounded text-white font-semibold transition-all duration-300 flex items-center justify-center w-full
        ${isSent ? 'bg-green-500 hover:bg-green-600' : 'bg-blue-500 hover:bg-blue-600'}
        ${(isSending || isSent) ? 'cursor-not-allowed opacity-75' : ''}
      `}
    >
      {isSending ? (
        <span className="flex items-center">
          <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          Sending...
        </span>
      ) : isSent ? (
        <span className="flex items-center">
          <CheckCircle className="mr-2" />
          Notified NDRF
        </span>
      ) : (
        <span className="flex items-center">
          <Mail className="mr-2" />
          Notify NDRF
        </span>
      )}
    </button>
  );
};

// const MapPanel = ({ alerts, selectedAlert }) => {
//   return (
//     // <div>
//     <MapContainer center={[20.5937, 78.9629]} zoom={5} style={{ height: '100%', width: '100%' }}>
//       <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
//       {alerts.map(alert => (
//         <Marker
//           key={alert.id}
//           position={[alert.lat, alert.lng]}
//           icon={customIcon}
//         >
//           <Popup className="rounded-lg shadow-lg">
//                <div className="p-2">
//                  <strong className="text-lg">{alert.type.charAt(0).toUpperCase() + alert.type.slice(1)}</strong><br />
//                  <strong>City:</strong> {alert.location}<br />
//                  <strong>Severity:</strong> <span className={`inline-block w-3 h-3 rounded-full ${severityColors[alert.severity]} mr-1`}></span> {alert.severity.charAt(0).toUpperCase() + alert.severity.slice(1)}<br />
//                  <strong>Affected:</strong> {alert.affected.toLocaleString()} people
//                </div>
//                <NotifyButton alert={alert} />
//              </Popup>
//         </Marker>
//       ))}
//       <MapViewUpdater selectedAlert={selectedAlert} alerts={alerts} />
//     </MapContainer>

//     // {/* <ToastContainer
//     //      position="top-right"
//     //      autoClose={3000}
//     //      hideProgressBar={false}
//     //      newestOnTop={false}
//     //      closeOnClick
//     //      rtl={false}
//     //      pauseOnFocusLoss
//     //      draggable
//     //      pauseOnHover
//     //      style={{ marginTop: '70px' }}
//     //    /> */}
       
//     // {/* </div> */}
//   );
// };

// export default MapPanel;


export default function MapPanel({ alerts, selectedAlert }) {
  useEffect(() => {
    const socket = io('http://localhost:5000'); // Connect to the socket server

    socket.on('alertUpdate', (updatedAlerts) => {
      console.log('Received alerts in MapPanel:', updatedAlerts); // Log the received alerts
      // Here you can update the state if you have a local state for alerts
    });

    return () => {
      socket.disconnect(); // Clean up on unmount
    };
  }, []);

  return (
    <div className="flex-1 bg-gray-300 p-4 shadow-inner relative z-0">
      <MapContainer center={[20.5937, 78.9629]} zoom={5} style={{ height: '100%', width: '100%' }} className="rounded-lg shadow-md">
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        {alerts.map(alert => (
          <Marker
            key={alert.id}
            position={[alert.lat, alert.lng]}
            icon={customIcon}
          >
            <Popup className="rounded-lg shadow-lg">
              <div className="p-2">
                <strong className="text-lg">{alert.type.charAt(0).toUpperCase() + alert.type.slice(1)}</strong><br />
                <strong>City:</strong> {alert.location}<br />
                <strong>Severity:</strong> <span className={`inline-block w-3 h-3 rounded-full ${severityColors[alert.severity]} mr-1`}></span> {alert.severity.charAt(0).toUpperCase() + alert.severity.slice(1)}<br />
                <strong>Affected:</strong> {alert.affected.toLocaleString()} people
              </div>
              <NotifyButton alert={alert} />
            </Popup>
          </Marker>
        ))}
        <MapViewUpdater selectedAlert={selectedAlert} alerts={alerts} />
      </MapContainer>

      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        style={{ marginTop: '70px' }}
      />
    </div>
  );
}
