// src/components/StatsPanel.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AnimatedNumber from './AnimatedNumber';

export default function StatsPanel({ activeDisasters, peopleAffected, resourcesDeployed, alerts }) {
  const navigate = useNavigate();

  const handleReportClick = () => {
    // Navigate to the report page
    navigate('/report');
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-md">
      <div className="flex flex-wrap justify-between items-center">
        <div className="flex flex-wrap gap-8">
          <div className="bg-blue-100 p-4 rounded-lg">
            <div className="text-sm font-medium text-blue-800">Active Disasters</div>
            <div className="text-3xl font-bold text-blue-900">
              <AnimatedNumber value={activeDisasters !== undefined ? activeDisasters : 0} duration={1200} />
            </div>
          </div>
          <div className="bg-red-100 p-4 rounded-lg">
            <div className="text-sm font-medium text-red-800">People Affected</div>
            <div className="text-3xl font-bold text-red-900">
              <AnimatedNumber value={peopleAffected !== undefined ? peopleAffected : 0} />
            </div>
          </div>
          <div className="bg-green-100 p-4 rounded-lg">
            <div className="text-sm font-medium text-green-800">Resources Deployed</div>
            <div className="text-3xl font-bold text-green-900">
              <AnimatedNumber value={resourcesDeployed !== undefined ? resourcesDeployed : 0} />
            </div>
          </div>
        </div>
        <button
          onClick={handleReportClick}
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          Generate Report
        </button>
      </div>
    </div>
  );
}
