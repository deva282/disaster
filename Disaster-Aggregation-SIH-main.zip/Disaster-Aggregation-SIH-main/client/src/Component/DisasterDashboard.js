import React, { useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import { useNavigate } from 'react-router-dom';
import SearchFilters from './SearchFilters';
import AlertItem from './AlertItem';
import MapPanel from './MapPanel';
import StatsPanel from './StatsPanel';

function DisasterDashboard({ user }) {
  const [alerts, setAlerts] = useState([]);
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [isRealTime, setIsRealTime] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterSeverity, setFilterSeverity] = useState('');
  const [filterState, setFilterState] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const socket = io('http://localhost:5000');

    // Remove the fetch request
    // fetch('http://localhost:5000/api/alerts')
    //   .then(response => response.json())
    //   .then(data => setAlerts(data))
    //   .catch(error => console.error('Error fetching alerts:', error));

    // WebSocket connection for real-time updates
    socket.on('alertUpdate', (updatedAlerts) => {
      setAlerts(updatedAlerts);
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const handleAlertClick = (alert) => {
    setSelectedAlert(alert.id); // Set the selected alert
  };

  // Filter alerts based on selected filters
  const filteredAlerts = alerts.filter(alert => 
    (filterType ? alert.type === filterType : true) &&
    (filterSeverity ? alert.severity === filterSeverity : true) &&
    (filterState ? alert.state === filterState : true)
  );

  const activeDisasters = filteredAlerts.length;
  const peopleAffected = filteredAlerts.reduce((total, alert) => total + alert.affected, 0);
  const resourcesDeployed = activeDisasters * 100;

  const handleReportClick = () => {
    navigate('/report', { state: { alerts: filteredAlerts } });
  };

  

  return (
    <div className="flex flex-col h-screen bg-gray-100 text-gray-800">
      <div className="flex flex-1 overflow-hidden flex-col md:flex-row">
        <div className="w-full md:w-1/3 border-r border-black bg-white flex flex-col">
          <SearchFilters
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            filterType={filterType}
            setFilterType={setFilterType}
            filterSeverity={filterSeverity}
            setFilterSeverity={setFilterSeverity}
            filterState={filterState}
            setFilterState={setFilterState}
          />
          <div className="flex-1 overflow-y-auto">
          {alerts
            .filter(alert => 
              (filterType ? alert.type === filterType : true) &&
              (filterSeverity ? alert.severity === filterSeverity : true) &&
              (filterState ? alert.state === filterState : true)
            )
            .map(alert => (
              <AlertItem
                key={alert.id}
                alert={alert}
                isSelected={selectedAlert === alert.id}
                onClick={() => handleAlertClick(alert)} // Handle click
              />
            ))}
        </div>
        </div>
        <div className="flex-1 flex flex-col">
        <MapPanel alerts={filteredAlerts} selectedAlert={selectedAlert} /> {/* Pass filtered alerts */}
        <StatsPanel
          activeDisasters={filteredAlerts.length} // Count of active disasters
          peopleAffected={filteredAlerts.reduce((total, alert) => total + alert.affected, 0)} // Total affected
          resourcesDeployed={filteredAlerts.length * 100} // Example: resources deployed
        />
      </div>
      </div>
    </div>
  );
}

export default DisasterDashboard;
