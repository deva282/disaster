import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, LogOut, AlertTriangle, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const LogoutConfirmation = ({ onConfirm, onCancel }) => {
  return (
    <motion.div
      className="fixed inset-0 backdrop-blur-sm bg-black/50 flex items-center justify-center z-[60]"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div
        className="bg-gray-800 rounded-lg p-6 w-96 relative shadow-xl"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 50, opacity: 0 }}
      >
        <div className="text-center mb-6">
          <div className="mx-auto w-12 h-12 flex items-center justify-center text-amber-500 mb-4">
            <AlertTriangle size={48} />
          </div>
          <h3 className="text-xl font-semibold mb-2 text-white">
            Confirm Logout
          </h3>
          <p className="text-gray-400">
            Are you sure you want to logout?
          </p>
        </div>
        
        <div className="flex space-x-4">
          <button
            onClick={onCancel}
            className="flex-1 px-4 py-2 rounded-lg transition duration-300 bg-gray-700 text-gray-200 hover:bg-gray-600"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition duration-300"
          >
            Logout
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
};

const UserProfile = ({ user, onClose, onLogout }) => {
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const navigate = useNavigate();

  const handleLogoutClick = () => {
    setShowLogoutConfirm(true);
  };

  const handleLogoutConfirm = () => {
    if (typeof onLogout === 'function') {
      onLogout();
      setShowLogoutConfirm(false);
      onClose();
      navigate('/login');
    } else {
      console.error('onLogout is not a function');
    }
  };

  const handleLogoutCancel = () => {
    setShowLogoutConfirm(false);
  };

  if (!user) {
    return null;
  }

  return (
    <motion.div 
      className="fixed inset-0 backdrop-blur-sm bg-black/50 flex items-center justify-center z-50"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div 
        className="bg-gray-800 rounded-lg w-[480px] relative flex flex-col shadow-xl"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 50, opacity: 0 }}
      >
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-200"
        >
          <X size={24} />
        </button>
        
        {/* Profile Header */}
        <div className="p-6 border-b border-gray-700">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-amber-500 rounded-full flex items-center justify-center text-white text-xl font-bold">
              {user.username?.charAt(0).toUpperCase()}
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">{user.username}</h2>
              <p className="text-gray-400">{user.email}</p>
            </div>
          </div>
        </div>

        {/* User Information */}
        <div className="p-6 space-y-4">
          <div className="flex items-center space-x-3 text-gray-300">
            <User size={20} />
            <span>User Information</span>
          </div>
          <div className="bg-gray-700/50 rounded-lg p-4 space-y-3">
            <div>
              <label className="text-gray-400 text-sm">Full Name</label>
              <p className="text-white">{user.username}</p>
            </div>
            <div>
              <label className="text-gray-400 text-sm">Email</label>
              <p className="text-white">{user.email}</p>
            </div>
          </div>
        </div>

        {/* Logout Button */}
        <div className="p-6 border-t border-gray-700 mt-auto">
          <button
            onClick={handleLogoutClick}
            className="w-full bg-red-600 text-white rounded-lg py-2 font-semibold hover:bg-red-700 transition duration-300 flex items-center justify-center space-x-2"
          >
            <LogOut size={20} />
            <span>Logout</span>
          </button>
        </div>
      </motion.div>

      <AnimatePresence>
        {showLogoutConfirm && (
          <LogoutConfirmation
            onConfirm={handleLogoutConfirm}
            onCancel={handleLogoutCancel}
          />
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default UserProfile;