"use client"

import React, { useState, useEffect, useRef } from 'react'
import { Bell, User, AlertTriangle, Home, BarChart, X } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { Link } from 'react-router-dom'
import { io } from 'socket.io-client'
import UserProfile from './UserProfile'

function Header({ isRealTime, setIsRealTime, user, onLogout }) {
  const [showNotifications, setShowNotifications] = useState(false)
  const [showProfile, setShowProfile] = useState(false)
  const [notifications, setNotifications] = useState([])
  const [notificationCount, setNotificationCount] = useState(0)
  const dropdownRef = useRef(null)
  const socket = useRef(null)

  useEffect(() => {
    socket.current = io('http://localhost:5000')

    socket.current.on('alertUpdate', (alerts) => {
      const newNotifications = alerts.map(alert => ({
        ...alert,
        isNew: true
      }))
      setNotifications(prevNotifications => [...newNotifications, ...prevNotifications])
      setNotificationCount(newNotifications.length)
    })

    socket.current.on('connect_error', (err) => {
      console.error('WebSocket connection error:', err)
    })

    socket.current.on('disconnect', () => {
      console.warn('WebSocket disconnected')
    })

    return () => {
      if (socket.current) {
        socket.current.disconnect()
      }
    }
  }, [])

  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowNotifications(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [dropdownRef])

  const handleNotificationClick = () => {
    setShowNotifications(!showNotifications)
    if (!showNotifications) {
      setNotificationCount(0)
      setNotifications(prevNotifications =>
        prevNotifications.map(notification => ({ ...notification, isNew: false }))
      )
    }
  }

  const removeNotification = (id) => {
    setNotifications(prevNotifications =>
      prevNotifications.filter(notification => notification.id !== id)
    )
    setNotificationCount(prevCount => Math.max(0, prevCount - 1))
  }

  return (
    <motion.header
      className="flex flex-col sm:flex-row items-center justify-between p-6 bg-gradient-to-r from-gray-800 to-gray-700 text-gray-100 shadow-lg relative z-20"
      initial={{ opacity: 0, y: -50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex items-center mb-4 sm:mb-0">
        <AlertTriangle className="w-8 h-8 mr-3 text-amber-500" />
        <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-amber-200 to-amber-500">
          India Disaster Information Aggregator
        </h1>
      </div>

      <div className="flex items-center space-x-6">
        <motion.div
          className="flex items-center space-x-3 bg-gray-700 rounded-full px-4 py-2"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <span className="text-sm font-medium">Real-time</span>
          <button
            className={`w-14 h-7 flex items-center rounded-full ${isRealTime ? 'bg-emerald-500' : 'bg-gray-500'} transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-300`}
            onClick={() => setIsRealTime(!isRealTime)}
          >
            <span className="sr-only">Toggle real-time updates</span>
            <motion.div
              className={`w-6 h-6 rounded-full bg-white shadow-md`}
              animate={{ x: isRealTime ? 28 : 2 }}
              transition={{ type: "spring", stiffness: 700, damping: 30 }}
            />
          </button>
        </motion.div>

        <Link to="/dashboard" className="flex items-center p-2 rounded-full bg-gray-700 hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-300 transition-colors duration-200">
          <span className="sr-only">Home</span>
          <Home className="w-6 h-6 text-gray-100" />
        </Link>

        <Link to="/disaster-stats" className="flex items-center p-2 rounded-full bg-gray-700 hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-300 transition-colors duration-200">
          <span className="sr-only">Disaster Stats</span>
          <BarChart className="w-6 h-6 text-gray-100" />
        </Link>

        <div className="relative">
          <motion.button
            className="p-2 rounded-full bg-gray-700 hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-300 transition-colors duration-200"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={handleNotificationClick}
          >
            <span className="sr-only">Notifications</span>
            <Bell className="w-6 h-6" />
            {notificationCount > 0 && (
              <span className="absolute -top-1 -right-1 px-2 py-1 text-xs font-bold leading-none text-red-100 bg-red-600 rounded-full">
                {notificationCount}
              </span>
            )}
          </motion.button>

          <AnimatePresence>
            {showNotifications && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className="absolute right-0 mt-2 w-96 z-50 bg-white rounded-lg shadow-lg text-black overflow-hidden"
                ref={dropdownRef}
              >
                <div className="p-4 border-b border-gray-200 relative z-10">
                  <h2 className="text-lg font-semibold text-gray-800">Notifications</h2>
                  <div className="mt-2 max-h-80 overflow-y-auto space-y-4">
                    {notifications.length > 0 ? (
                      notifications.map((notification) => (
                        <motion.div
                          key={notification.id}
                          className={`bg-white rounded-lg shadow-md p-4 mb-4 border ${notification.isNew ? 'border-blue-500' : 'border-gray-200'} relative`}
                          initial={{ opacity: 0, y: -20 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -20 }}
                          transition={{ duration: 0.3 }}
                        >
                          <button
                            onClick={() => removeNotification(notification.id)}
                            className="absolute top-2 right-2 text-gray-500 hover:text-red-500 focus:outline-none"
                          >
                            <X className="w-4 h-4" />
                            <span className="sr-only">Remove notification</span>
                          </button>
                          <h3 className="text-lg font-semibold text-blue-600">{notification.type.charAt(0).toUpperCase() + notification.type.slice(1)} Alert</h3>
                          <p className="text-sm text-gray-500">Location: {notification.location}</p>
                          <p className="text-sm text-gray-500">Time: {notification.time}</p>
                          <p className="text-sm text-gray-500">Severity: {notification.severity}</p>
                          <p className="text-sm text-gray-500">Affected: {notification.affected}</p>
                          <div className="mt-3 space-y-2">
                            {(notification.tweets || []).map((tweet, index) => (
                              <div key={index} className="p-3 bg-gray-100 rounded-md text-sm text-gray-700 border-l-4 border-blue-500">
                                "{tweet}"
                              </div>
                            ))}
                          </div>
                        </motion.div>
                      ))
                    ) : (
                      <p className="p-4 text-center text-gray-500">No notifications available.</p>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Profile Button */}
        <motion.button
          onClick={() => setShowProfile(true)}
          className="flex items-center space-x-2 bg-gray-700 hover:bg-gray-600 rounded-full px-4 py-2 transition-colors duration-300"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <div className="w-8 h-8 bg-amber-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
            {user?.username?.charAt(0).toUpperCase()}
          </div>
          <span className="text-gray-200">{user?.username || 'Login'}</span>
        </motion.button>
      </div>

      {/* Profile Modal */}
      <AnimatePresence>
        {showProfile && (
          <UserProfile
            user={user}
            onClose={() => setShowProfile(false)}
            onLogout={onLogout}
          />
        )}
      </AnimatePresence>
    </motion.header>
  )
}

export default Header