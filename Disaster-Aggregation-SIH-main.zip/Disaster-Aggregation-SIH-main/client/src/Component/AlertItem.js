// src/components/AlertItem.js
import React from 'react';

const disasterTypes = {
  earthquake: { icon: '🌋', color: 'bg-yellow-500' },
  flood: { icon: '🌊', color: 'bg-blue-500' },
  cyclone: { icon: '🌀', color: 'bg-cyan-500' },
  drought: { icon: '☀️', color: 'bg-orange-500' },
  tsunami: { icon: '🌊', color: 'bg-blue-700' },
  landslide: { icon: '⛰️', color: 'bg-brown-500' },
  volcanic: { icon: '🌋', color: 'bg-red-700' },
  wildfire: { icon: '🔥', color: 'bg-red-500' },
  storm: { icon: '⛈️', color: 'bg-gray-500' },
  tornado: { icon: '🌪️', color: 'bg-purple-500' },
  heatwave: { icon: '🌡️', color: 'bg-red-600' },
  blizzard: { icon: '❄️', color: 'bg-blue-200' },
  avalanche: { icon: '🏔️', color: 'bg-gray-200' }
};

const severityColors = {
  low: 'bg-green-500',
  moderate: 'bg-yellow-500',
  severe: 'bg-red-500',
  critical: 'bg-purple-500',
};

const AlertItem = ({ alert, isSelected, onClick }) => {

  const type = disasterTypes[alert.type] || { icon: '❓', color: 'bg-gray-500' };
  const severity = severityColors[alert.severity] || 'bg-gray-500';

  return (
    <div
      key={alert.id}
      className={`p-4 border-b cursor-pointer hover:bg-gray-50 transition-all duration-300 hover:shadow-2xl transform hover:-translate-y-1 hover:scale-[1.02] ${isSelected ? 'bg-blue-50' : ''}`}
      onClick={onClick}
    >
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center space-x-2">
          <span className={`p-1 rounded-full ${type.color}`}>
            {type.icon}
          </span>
          <span className={`font-semibold uppercase text-lg`}>
            {alert.type.charAt(0).toUpperCase() + alert.type.slice(1)}
          </span>
        </div>
        <span className={`px-2 py-1 rounded text-xs text-white ${severity} uppercase text-20`}>
          {alert.severity}
        </span>
      </div>
      <div className="text-sm text-gray-600 mb-2">{alert.location}</div>
      <div className="flex justify-between text-sm">
        <span>{alert.affected.toLocaleString()} affected</span>
        <span>{alert.time}</span>
      </div>
    </div>
  );
};

export default AlertItem;
