import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

const AnimatedNumber = ({ value, duration = 1000 }) => {
  const [displayValue, setDisplayValue] = useState(value);

  useEffect(() => {
    const start = performance.now();
    const animate = (time) => {
      const elapsed = time - start;
      const progress = Math.min(elapsed / duration, 1);
      const newValue = Math.round(displayValue + (value - displayValue) * progress);
      setDisplayValue(newValue);

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);

    // Cleanup is handled by the animation frame mechanism
    return () => cancelAnimationFrame(animate);
  }, [value, duration]); // Keep dependencies to 'value' and 'duration'

  return (
    <motion.div>
      {displayValue.toLocaleString()}
    </motion.div>
  );
};

export default AnimatedNumber;
