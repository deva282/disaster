import React, { useEffect, useState } from 'react';
import { Line, Bar, Doughnut } from 'react-chartjs-2';
import 'chart.js/auto';
import { AlertTriangle, Users, MapPin, Thermometer, Wind, Droplet } from 'lucide-react';
import io from 'socket.io-client';

// Chart options
const lineChartOptions = {
  responsive: true,
  scales: {
    x: {
      title: { display: true, text: 'Time' },
      grid: { color: 'rgba(255, 255, 255, 0.1)' },
    },
    y: {
      beginAtZero: true,
      title: { display: true, text: 'Affected People' },
      grid: { color: 'rgba(255, 255, 255, 0.1)' },
    },
  },
  plugins: {
    legend: { labels: { color: 'white' } },
  },
};

const barChartOptions = {
  responsive: true,
  scales: {
    x: {
      title: { display: true, text: 'Category' },
      grid: { color: 'rgba(255, 255, 255, 0.1)' },
    },
    y: {
      beginAtZero: true,
      title: { display: true, text: 'Count' },
      grid: { color: 'rgba(255, 255, 255, 0.1)' },
    },
  },
  plugins: {
    legend: { labels: { color: 'white' } },
  },
};

const doughnutChartOptions = {
  responsive: true,
  plugins: {
    legend: {
      position: 'bottom',
      labels: { color: 'white' },
    },
  },
};

const DisasterStats = () => {
  const [data, setData] = useState([]);
  const [chartData, setChartData] = useState({
    affectedPeople: [],
    activeDisasters: [],
    disasterLabels: [],
    cityDisasterCounts: [],
    cityLabels: [],
    timeLabels: [],
    severityDistribution: [],
  });
  const [isRealTime, setIsRealTime] = useState(true);
  const [selectedDisaster, setSelectedDisaster] = useState(null);
  const [timeRange, setTimeRange] = useState('24h');

  useEffect(() => {
    const socket = io('http://localhost:5000');

    socket.on('alertUpdate', (updatedAlerts) => {
      setData(updatedAlerts);
      processChartData(updatedAlerts);
    });

    return () => {
      socket.disconnect();
    };
  }, [isRealTime, timeRange]);

  const processChartData = (data) => {
    // Aggregate disaster counts by type
    const disasterTypeCounts = data.reduce((acc, item) => {
      acc[item.type] = (acc[item.type] || 0) + 1;
      return acc;
    }, {});

    const disasterLabels = Object.keys(disasterTypeCounts);
    const activeDisasters = Object.values(disasterTypeCounts);

    // Aggregate disaster counts by city
    const cityDisasterCounts = data.reduce((acc, item) => {
      acc[item.location] = (acc[item.location] || 0) + 1;
      return acc;
    }, {});

    const cityLabels = Object.keys(cityDisasterCounts);
    const cityDisasters = Object.values(cityDisasterCounts);

    // Affected people data and time labels
    const affectedPeople = data.map(item => item.affected);
    const timeLabels = data.map(item => item.time);

    // Severity distribution
    const severityDistribution = data.reduce((acc, item) => {
      acc[item.severity] = (acc[item.severity] || 0) + 1;
      return acc;
    }, {});

    setChartData({
      affectedPeople,
      activeDisasters,
      disasterLabels,
      cityDisasterCounts: cityDisasters,
      cityLabels,
      timeLabels,
      severityDistribution: Object.values(severityDistribution),
    });
  };

  const getDisasterIcon = (type) => {
    switch (type.toLowerCase()) {
      case 'earthquake': return <AlertTriangle className="w-6 h-6 text-red-500" />;
      case 'flood': return <Droplet className="w-6 h-6 text-blue-500" />;
      case 'hurricane': return <Wind className="w-6 h-6 text-teal-500" />;
      case 'wildfire': return <Thermometer className="w-6 h-6 text-orange-500" />;
      default: return <AlertTriangle className="w-6 h-6 text-yellow-500" />;
    }
  };

  const handleDisasterClick = (disaster) => {
    setSelectedDisaster(disaster);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Disaster Statistics Dashboard</h1>
        <div className="flex space-x-4">
          <select
            className="bg-gray-800 text-white rounded-md px-3 py-2"
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
          >
            <option value="24h">Last 24 Hours</option>
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <StatCard
          title="Total Affected People"
          value={chartData.affectedPeople.reduce((a, b) => a + b, 0)}
          icon={<Users className="w-8 h-8 text-blue-400" />}
        />
        <StatCard
          title="Active Disasters"
          value={chartData.activeDisasters.reduce((a, b) => a + b, 0)}
          icon={<AlertTriangle className="w-8 h-8 text-red-400" />}
        />
        <StatCard
          title="Affected Cities"
          value={chartData.cityLabels.length}
          icon={<MapPin className="w-8 h-8 text-green-400" />}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <ChartCard title="Affected People Over Time">
          <Line
            data={{
              labels: chartData.timeLabels,
              datasets: [
                {
                  label: 'Affected People',
                  data: chartData.affectedPeople,
                  borderColor: '#FF5733',
                  backgroundColor: 'rgba(255, 87, 51, 0.3)',
                  borderWidth: 2,
                }
              ]
            }}
            options={lineChartOptions}
          />
        </ChartCard>

        <ChartCard title="Disasters by Type">
          <Bar
            data={{
              labels: chartData.disasterLabels,
              datasets: [
                {
                  label: 'Number of Disasters',
                  data: chartData.activeDisasters,
                  backgroundColor: '#33FF57',
                }
              ]
            }}
            options={barChartOptions}
          />
        </ChartCard>

        <ChartCard title="Disasters by City">
          <div 
            style={{ 
              height: '800px', 
              width: '100%', 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center',
              background: '#1f2937', 
              borderRadius: '8px', 
              padding: '20px', 
            }}
          >
            <Bar
              data={{
                labels: chartData.cityLabels,
                datasets: [
                  {
                    label: 'Number of Disasters',
                    data: chartData.cityDisasterCounts,
                    backgroundColor: '#337AB7',
                  }
                ]
              }}
              options={{
                ...barChartOptions,
                responsive: true,
                maintainAspectRatio: false,
              }}
            />
          </div>
        </ChartCard>

        <ChartCard title="Severity Distribution">
          <Doughnut
            data={{
              labels: ['Low', 'Medium', 'High', 'Critical'],
              datasets: [
                {
                  data: chartData.severityDistribution,
                  backgroundColor: ['#4CAF50', '#FFC107', '#FF9800', '#F44336'],
                }
              ]
            }}
            options={doughnutChartOptions}
          />
        </ChartCard>
      </div>

      <div className="mt-6">
        <h2 className="text-2xl font-semibold mb-4">Recent Disasters</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {data.map((disaster, index) => (
            <div
              key={index}
              className="bg-gray-800 p-4 rounded-lg shadow-lg cursor-pointer hover:bg-gray-700"
              onClick={() => handleDisasterClick(disaster)}
            >
              {getDisasterIcon(disaster.type)}
              <h3 className="text-xl font-medium mt-2">{disaster.type}</h3>
              <p className="text-gray-400">{disaster.location}</p>
              <p className="text-gray-400">Severity: {disaster.severity}</p>
              <p className="text-gray-400">Affected: {disaster.affected}</p>
              <p className="text-gray-400">Time: {disaster.time}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, icon }) => (
  <div className="bg-gray-800 p-6 rounded-lg shadow-md flex items-center space-x-4">
    <div className="text-4xl">{icon}</div>
    <div>
      <h3 className="text-xl font-semibold">{title}</h3>
      <p className="text-3xl font-bold">{value}</p>
    </div>
  </div>
);

const ChartCard = ({ title, children }) => (
  <div className="bg-gray-800 p-6 rounded-lg shadow-md">
    <h3 className="text-xl font-semibold mb-4">{title}</h3>
    {children}
  </div>
);

export default DisasterStats;
