import React, { useState, useEffect, useRef } from 'react';
import { AlertTriangle } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';

export default function OtpVerificationPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { email, password } = location.state || {}; // Retrieve both email and password from state
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);
  const [timer, setTimer] = useState(30);
  const inputRefs = useRef([]);

  useEffect(() => {
    if (timer > 0) {
      const interval = setInterval(() => setTimer((prevTimer) => prevTimer - 1), 1000);
      return () => clearInterval(interval);
    }
  }, [timer]);

  const handleOtpChange = (index, value) => {
    if (value.length > 1) return;
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value && index < inputRefs.current.length - 1) {
      inputRefs.current[index + 1].focus();
    }
  };

  const handleSubmitOtp = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess(false);

    const fullOtp = otp.join('');
    if (fullOtp.length !== 6) {
      setError('Please enter the full OTP.');
      setLoading(false);
      return;
    }

    console.log('Sending data:', { email, password, otp: fullOtp });

    try {
      const response = await fetch('http://localhost:5000/complete-registration', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, otp: fullOtp }),
      });

      console.log('Response status:', response.status);

      if (response.ok) {
        setSuccess(true);
        setTimeout(() => {
          navigate('/'); // Redirect to home page after successful verification
        }, 1000);
      } else {
        const data = await response.json();
        setError(data.message || 'OTP verification failed');
      }
    } catch (error) {
      console.error('Fetch error:', error);
      setError('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleResendOtp = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await fetch('http://localhost:5000/resend-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });

      if (response.ok) {
        setTimer(30);
        setSuccess(false);
      } else {
        const data = await response.json();
        setError(data.message || 'Failed to resend OTP');
      }
    } catch (error) {
      setError('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 to-blue-900 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white bg-opacity-10 backdrop-filter backdrop-blur-lg p-10 rounded-xl shadow-2xl relative z-10">
        <div>
          <div className="flex justify-center">
            <AlertTriangle className="h-20 w-20 text-yellow-500 animate-pulse" />
          </div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-white">Verify Your Email</h2>
          <p className="mt-2 text-center text-sm text-gray-300">Please enter the 6-digit OTP sent to your email: {email}</p>
        </div>

        <form className="mt-8 space-y-6" onSubmit={handleSubmitOtp}>
          <div className="flex justify-center space-x-2">
            {otp.map((digit, index) => (
              <input
                key={index}
                ref={(el) => (inputRefs.current[index] = el)}
                type="text"
                maxLength="1"
                className="w-12 h-12 text-center text-2xl border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500 transition-all duration-300 bg-white bg-opacity-80"
                value={digit}
                onChange={(e) => handleOtpChange(index, e.target.value)}
              />
            ))}
          </div>

          {error && (
            <div className="rounded-md bg-red-500 bg-opacity-20 p-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <AlertTriangle className="h-5 w-5 text-red-400" />
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-red-300">{error}</h3>
                </div>
              </div>
            </div>
          )}

          <div>
            <button
              type="submit"
              className={`group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-all duration-300 ease-in-out transform hover:scale-105 ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
              disabled={loading}
            >
              {loading ? 'Verifying...' : 'Verify OTP'}
            </button>
          </div>

          <div className="text-center mt-6">
            <p className="text-sm text-gray-300">
              Didn't receive the code?{' '}
              {timer > 0 ? (
                <span>Resend in {timer} seconds</span>
              ) : (
                <button
                  type="button"
                  className="text-red-500 hover:text-red-300 transition-all duration-300 focus:outline-none"
                  onClick={handleResendOtp}
                >
                  Resend OTP
                </button>
              )}
            </p>
          </div>
        </form>
      </div>
    </div>
  );
}
