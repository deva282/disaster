import React, { useState } from 'react';

const disasterTypes = {
  cyclone: { icon: '🌀', color: 'bg-cyan-500' },
  flood: { icon: '🌊', color: 'bg-blue-500' },
  earthquake: { icon: '🌋', color: 'bg-yellow-500' },
  heatwave: { icon: '🔥', color: 'bg-red-500' },
};

const severityColors = {
  low: 'bg-green-500',
  moderate: 'bg-yellow-500',
  severe: 'bg-red-500',
  critical: 'bg-purple-500',
};

const mockAlerts = [
  { id: 1, type: 'cyclone', location: 'Chennai, Tamil Nadu', severity: 'severe', affected: 500000, time: '5 minutes ago' },
  { id: 2, type: 'flood', location: 'Mumbai, Maharashtra', severity: 'moderate', affected: 100000, time: '1 hour ago' },
  { id: 3, type: 'earthquake', location: 'Dehradun, Uttarakhand', severity: 'critical', affected: 25000, time: '30 minutes ago' },
  { id: 4, type: 'heatwave', location: 'New Delhi, Delhi', severity: 'severe', affected: 1000000, time: '2 hours ago' },
  { id: 5, type: 'flood', location: 'Guwahati, Assam', severity: 'severe', affected: 200000, time: '45 minutes ago' },
];

const indianStates = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat', 'Haryana',
  'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur',
  'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana',
  'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal', 'Delhi', 'Jammu and Kashmir', 'Ladakh',
  'Puducherry', 'Andaman and Nicobar Islands', 'Chandigarh', 'Dadra and Nagar Haveli and Daman and Diu',
  'Lakshadweep',
];

function DisasterDashboard() {
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [isRealTime, setIsRealTime] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterSeverity, setFilterSeverity] = useState('');
  const [filterState, setFilterState] = useState('');

  const filteredAlerts = mockAlerts.filter(alert => 
    alert.location.toLowerCase().includes(searchTerm.toLowerCase()) &&
    (filterType === '' || alert.type === filterType) &&
    (filterSeverity === '' || alert.severity === filterSeverity) &&
    (filterState === '' || alert.location.includes(filterState))
  );

  return (
    <div className="flex flex-col h-screen bg-gray-100 text-gray-800">
      {/* Top Bar */}
      <header className="flex items-center justify-between p-4 bg-white shadow">
        <h1 className="text-2xl font-bold">India Disaster Information Aggregator</h1>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <span>Real-time</span>
            <button
              className={`w-12 h-6 rounded-full ${isRealTime ? 'bg-green-500' : 'bg-gray-300'} transition-colors duration-200 focus:outline-none`}
              onClick={() => setIsRealTime(!isRealTime)}
            >
              <div className={`w-4 h-4 rounded-full bg-white transform transition-transform duration-200 ${isRealTime ? 'translate-x-7' : 'translate-x-1'}`} />
            </button>
          </div>
          <button className="p-2 rounded-full bg-gray-200 hover:bg-gray-300 focus:outline-none">
            <span className="sr-only">Notifications</span>
            🔔
          </button>
          <button className="p-2 rounded-full bg-gray-200 hover:bg-gray-300 focus:outline-none">
            <span className="sr-only">User profile</span>
            👤
          </button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Panel */}
        <div className="w-1/3 border-r bg-white flex flex-col">
          {/* Search and Filters */}
          <div className="p-4 border-b">
            <input
              type="text"
              placeholder="Search locations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full p-2 border rounded mb-4"
            />
            <div className="flex space-x-2 mb-2">
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="flex-1 p-2 border rounded"
              >
                <option value="">All Types</option>
                {Object.keys(disasterTypes).map(type => (
                  <option key={type} value={type}>{type.charAt(0).toUpperCase() + type.slice(1)}</option>
                ))}
              </select>
              <select
                value={filterSeverity}
                onChange={(e) => setFilterSeverity(e.target.value)}
                className="flex-1 p-2 border rounded"
              >
                <option value="">All Severities</option>
                {Object.keys(severityColors).map(severity => (
                  <option key={severity} value={severity}>{severity.charAt(0).toUpperCase() + severity.slice(1)}</option>
                ))}
              </select>
            </div>
            <select
              value={filterState}
              onChange={(e) => setFilterState(e.target.value)}
              className="w-full p-2 border rounded"
            >
              <option value="">All States</option>
              {indianStates.map(state => (
                <option key={state} value={state}>{state}</option>
              ))}
            </select>
          </div>

          {/* Alerts Feed */}
          <div className="flex-1 overflow-y-auto">
            {filteredAlerts.map((alert) => (
              <div
                key={alert.id}
                className={`p-4 border-b cursor-pointer hover:bg-gray-50 ${selectedAlert === alert.id ? 'bg-blue-50' : ''}`}
                onClick={() => setSelectedAlert(alert.id)}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <span className={`p-1 rounded-full ${disasterTypes[alert.type].color}`}>
                      {disasterTypes[alert.type].icon}
                    </span>
                    <span className="font-semibold">{alert.type.charAt(0).toUpperCase() + alert.type.slice(1)}</span>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs text-white ${severityColors[alert.severity]}`}>
                    {alert.severity}
                  </span>
                </div>
                <div className="text-sm text-gray-600 mb-2">{alert.location}</div>
                <div className="flex justify-between text-sm">
                  <span>{alert.affected.toLocaleString()} affected</span>
                  <span>{alert.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Panel (Map) */}
        <div className="flex-1 flex flex-col">
          <div className="flex-1 bg-gray-200 p-4">
            <div className="h-full bg-white rounded-lg border flex items-center justify-center">
              <div className="text-center">
                <div className="text-6xl mb-4">🗺️</div>
                <p className="text-gray-600">Interactive map of India would be displayed here</p>
                <p className="text-sm text-gray-500 mt-2">
                  Showing disaster locations, severity indicators, and allowing user interactions
                </p>
              </div>
            </div>
          </div>

          {/* Bottom Bar (Statistics and Insights) */}
          <div className="p-4 bg-white border-t">
            <div className="flex justify-between items-center">
              <div className="flex space-x-4">
                <div>
                  <div className="text-sm text-gray-600">Active Disasters</div>
                  <div className="text-2xl font-semibold">24</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">People Affected</div>
                  <div className="text-2xl font-semibold">1.2Cr</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Resources Deployed</div>
                  <div className="text-2xl font-semibold">500</div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-2xl">📈</span>
                <span className="text-sm text-gray-600">Trend analysis and predictions would be shown here</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default DisasterDashboard;