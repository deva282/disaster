import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import DisasterDashboard from './Component/DisasterDashboard';
import DisasterStats from './Component/DisasterStats';
import ReportPage from './Component/ReportPage';
import LoginPage from './Component/LoginPage';
import RegisterPage from './Component/RegisterPage';
import OtpVerificationPage from './Component/OtpVerificationPage';
import Header from './Component/Header';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check for existing login session on app load
  useEffect(() => {
    const token = localStorage.getItem('token');
    const savedUser = localStorage.getItem('user');
    
    if (token && savedUser) {
      setIsAuthenticated(true);
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const handleLogin = (status, userData) => {
    setIsAuthenticated(status);
    setUser(userData);
    if (status && userData) {
      localStorage.setItem('token', userData.token);
      localStorage.setItem('user', JSON.stringify(userData));
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUser(null);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/login'; // Force a full page reload to clear any state
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <Router>
      <div className="flex flex-col min-h-screen">
        {isAuthenticated && (
          <Header 
            user={user} 
            onLogout={handleLogout}
            isRealTime={true}
            setIsRealTime={() => {}}
          />
        )}
        <div className="flex-grow">
          <Routes>
            <Route path="/" element={<Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />} />
            <Route path="/login" element={
              isAuthenticated ? <Navigate to="/dashboard" replace /> : <LoginPage onLogin={handleLogin} />
            } />
            <Route path="/register" element={<RegisterPage onRegister={handleLogin} />} />
            <Route path="/otp-verification" element={<OtpVerificationPage />} />
            <Route path="/dashboard" element={
              <ProtectedRoute isAuthenticated={isAuthenticated}>
                <DisasterDashboard user={user} />
              </ProtectedRoute>
            } />
            <Route path="/report" element={
              <ProtectedRoute isAuthenticated={isAuthenticated}>
                <ReportPage user={user} />
              </ProtectedRoute>
            } />
            <Route path="/disaster-stats" element={
              <ProtectedRoute isAuthenticated={isAuthenticated}>
                <DisasterStats user={user} />
              </ProtectedRoute>
            } />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

function ProtectedRoute({ isAuthenticated, children }) {
  return isAuthenticated ? children : <Navigate to="/login" replace />;
}

export default App;