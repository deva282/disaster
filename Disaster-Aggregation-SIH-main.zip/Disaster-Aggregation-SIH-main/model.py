from flask import Flask
import json
import time
from datetime import datetime, timedelta
import threading
import ollama
import os
from newsapi import NewsApiClient
from concurrent.futures import ThreadPoolExecutor
import asyncio

app = Flask(__name__)

NEWS_API_KEY = "439f6143e95c4e62947193dcfe50930c"
ALERTS_FILE_PATH = "server/data/alerts.json"
MAX_WORKERS = 5  # Number of parallel processes

# Initialize NewsAPI client
newsapi = NewsApiClient(api_key=NEWS_API_KEY)

def initialize_alerts_file():
    if not os.path.exists(ALERTS_FILE_PATH):
        with open(ALERTS_FILE_PATH, 'w') as f:
            json.dump([], f, indent=2)

def fetch_disaster_news():
    """Fetch worldwide disaster news from the last week"""
    try:
        to_date = datetime.now()
        from_date = to_date - timedelta(days=7)  # Last week's news
        
        all_articles = []
        disaster_keywords = [
            'earthquake', 'flood', 'cyclone', 'drought', 'tsunami', 
            'landslide', 'volcanic eruption', 'wildfire', 'storm'
        ]
        
        # Fetch news for each disaster type separately
        for disaster in disaster_keywords:
            try:
                articles = newsapi.get_everything(
                    q=f'{disaster} AND (disaster OR emergency OR casualties OR damage)',
                    language='en',
                    sort_by='publishedAt',
                    from_param=from_date.strftime('%Y-%m-%d'),
                    to=to_date.strftime('%Y-%m-%d'),
                    page_size=100
                )
                
                if articles['status'] == 'ok':
                    filtered_articles = [
                        {**article, 'disaster_type': disaster}
                        for article in articles['articles']
                        if article.get('title') and article.get('description')
                    ]
                    all_articles.extend(filtered_articles)
                    print(f"Fetched {len(filtered_articles)} articles for {disaster}")
                
            except Exception as e:
                print(f"Error fetching {disaster} news: {e}")
                continue
                
        return all_articles
            
    except Exception as e:
        print(f"Error in fetch_disaster_news: {e}")
        return []

def process_single_article(args):
    """Process a single article with Llama"""
    article, current_id = args
    
    # Pre-determine disaster type from article
    disaster_type = article.get('disaster_type', 'earthquake')
    
    prompt = f"""Given this disaster news, create a JSON alert about a disaster in this EXACT format:
    {{
        "id": {current_id},
        "type": "{disaster_type}",
        "location": "City, State/Country",
        "severity": "mild" or "moderate" or "severe" or "high",
        "affected": <number between 1000-100000>,
        "time": "1 hour ago",
        "lat": <exact latitude of the location>,
        "lng": <exact longitude of the location>,
        "tweets": [
            "{article['title']}",
            "Stay informed about the {disaster_type} situation. Follow official guidelines and stay safe."
        ]
    }}

    IMPORTANT: 
    - Location must be a real place with exact coordinates
    - Do not use null or empty values
    - Only respond with valid JSON
    - Include exact latitude and longitude for the location

    Article Title: {article['title']}
    Description: {article['description']}
    Published: {article['publishedAt']}
    """
    
    try:
        response = ollama.generate(
            model='llama3:latest',
            prompt=prompt,
            stream=False,
            options={
                "temperature": 0.3,
                "top_p": 0.9,
                "num_predict": 512,
            }
        )
        
        json_str = response['response']
        start = json_str.find('{')
        end = json_str.rfind('}') + 1
        
        if start != -1 and end != 0:
            try:
                alert = json.loads(json_str[start:end])
                
                # Strict validation of required fields
                required_fields = ['id', 'type', 'location', 'lat', 'lng']
                if not all(field in alert and alert[field] is not None and alert[field] != "" for field in required_fields):
                    print(f"Skipping alert {current_id}: Missing required fields")
                    return None
                
                # Validate numeric fields
                if not isinstance(alert['lat'], (int, float)) or not isinstance(alert['lng'], (int, float)):
                    print(f"Skipping alert {current_id}: Invalid coordinates")
                    return None
                
                # Validate and clean other fields
                if (isinstance(alert['affected'], (int, float)) and 
                    alert['severity'] in ['mild', 'moderate', 'severe', 'high'] and
                    len(alert['tweets']) == 2):
                    
                    alert['id'] = current_id
                    alert['affected'] = max(1000, min(100000, int(alert['affected'])))
                    alert['time'] = "1 hour ago"
                    return alert
                    
            except json.JSONDecodeError:
                print(f"Skipping alert {current_id}: Invalid JSON")
                
    except Exception as e:
        print(f"Error processing article {current_id}: {e}")
    
    return None

def update_alerts_file(new_alert):
    """Update the alerts.json file with a single new alert"""
    try:
        with open(ALERTS_FILE_PATH, 'r') as f:
            alerts = json.load(f)
        
        # Double check alert validity before adding
        required_fields = ['id', 'type', 'location', 'lat', 'lng']
        if new_alert and all(field in new_alert and new_alert[field] is not None for field in required_fields):
            alerts.insert(0, new_alert)
            alerts = alerts[:40]
            
            with open(ALERTS_FILE_PATH, 'w') as f:
                json.dump(alerts, f, indent=2)
                print(f"Added alert: {new_alert['type']} in {new_alert['location']} ({new_alert['lat']}, {new_alert['lng']})")
        
    except Exception as e:
        print(f"Error updating alerts file: {e}")

def update_loop():
    """Continuous loop to update alerts"""
    current_id = 1
    
    while True:
        try:
            print("\nFetching news articles...")
            articles = fetch_disaster_news()
            
            if articles:
                print(f"Processing {len(articles)} articles in parallel...")
                
                # Process articles in parallel
                with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                    article_args = [(article, i) for i, article in enumerate(articles, start=current_id)]
                    for alert in executor.map(process_single_article, article_args):
                        if alert:
                            update_alerts_file(alert)
                            current_id += 1
                
                print(f"Processed batch of {len(articles)} articles")
            
            print("Waiting 60 seconds before next update...")
            time.sleep(60)  # Update every minute
            
        except Exception as e:
            print(f"Error in update loop: {e}")
            time.sleep(30)

@app.route('/health')
def health_check():
    return {'status': 'healthy'}

if __name__ == '__main__':
    initialize_alerts_file()
    update_thread = threading.Thread(target=update_loop, daemon=True)
    update_thread.start()
    app.run(port=5001, debug=False)
