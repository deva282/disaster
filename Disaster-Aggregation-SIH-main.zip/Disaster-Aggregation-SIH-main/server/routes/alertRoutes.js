const express = require('express');
const router = express.Router();
const { sendAlert } = require('../controllers/alertController');
const authMiddleware = require('../middleware/auth');

router.post('/email', authMiddleware, sendAlert);

module.exports = router;