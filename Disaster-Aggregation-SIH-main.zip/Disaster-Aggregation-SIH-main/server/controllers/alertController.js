const { sendAlertEmail } = require('../services/emailService');

const sendAlert = async (req, res) => {
  try {
    const alertData = req.body;
    await sendAlertEmail(alertData);
    res.status(200).json({ message: 'Alert email sent successfully' });
  } catch (error) {
    console.error('Error sending alert:', error);
    res.status(500).json({ error: 'Failed to send alert email' });
  }
};

module.exports = { sendAlert };