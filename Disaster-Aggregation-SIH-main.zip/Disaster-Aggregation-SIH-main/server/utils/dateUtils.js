const parseDate = (dateString) => {
    const now = new Date();
    
    if (dateString.includes("minutes ago")) {
      const minutes = parseInt(dateString.split(" ")[0], 10);
      now.setMinutes(now.getMinutes() - minutes);
    } else if (dateString.includes("hours ago")) {
      const hours = parseInt(dateString.split(" ")[0], 10);
      now.setHours(now.getHours() - hours);
    } else if (dateString.includes("days ago")) {
      const days = parseInt(dateString.split(" ")[0], 10);
      now.setDate(now.getDate() - days);
    }
    
    return now;
  };
  
  module.exports = { parseDate };