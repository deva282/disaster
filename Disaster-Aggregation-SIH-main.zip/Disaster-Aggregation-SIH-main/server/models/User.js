const mongoose = require('mongoose');

// Define the user schema
const userSchema = new mongoose.Schema({
  fullName: { // Added fullName field
    type: String,
    required: true,
    trim: true, // Removes whitespace from the beginning and end
  },
  email: {
    type: String,
    required: true,
    unique: true, // Ensures no two users can have the same email
    trim: true, // Removes whitespace from the beginning and end
    lowercase: true, // Converts email to lowercase for consistency
  },
  password: {
    type: String,
    required: true,
  },
}, {
  timestamps: true, // Adds createdAt and updatedAt fields
});

// Export the User model
module.exports = mongoose.model('User', userSchema);
