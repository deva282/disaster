const mongoose = require('mongoose');

const alertSchema = new mongoose.Schema({
  id: {
    type: Number,
    required: true,
    unique: true,
  },
  type: {
    type: String,
    required: true,
  },
  location: {
    type: String,
    required: true,
  },
  severity: {
    type: String,
    required: true,
  },
  affected: {
    type: Number,
    required: true,
  },
  time: {
    type: Date,
    required: true,
  },
  lat: {
    type: Number,
    required: true,
  },
  lng: {
    type: Number,
    required: true,
  },
  tweets: [String]  // Add this line to include the tweets field
});

const Alert = mongoose.model('Alert', alertSchema);

module.exports = Alert;
