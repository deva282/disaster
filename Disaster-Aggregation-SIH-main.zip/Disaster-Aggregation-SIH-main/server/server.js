const express = require('express');
const http = require('http');
const cors = require('cors');
const dotenv = require('dotenv');
const { initializeSocket } = require('./services/socketService');
const { connectDatabase } = require('./config/database');
const alertRoutes = require('./routes/alertRoutes');
const authRoutes = require('./routes/authRoutes');

// Load environment variables
dotenv.config();

const app = express();
const server = http.createServer(app);

// Initialize socket.io
initializeSocket(server);

// Middleware setup
app.use(cors({ origin: 'http://localhost:3000' }));
app.use(express.json());
app.use(express.static('public'));

// Routes
app.use('/api', alertRoutes);
app.use('/auth', authRoutes);

// Connect to MongoDB and start server
connectDatabase().then(() => {
  const PORT = process.env.PORT || 5000;
  server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });
});