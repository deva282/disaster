const fs = require('fs');
const path = require('path');
const chokidar = require('chokidar');
const Alert = require('../models/Alert');
const { parseDate } = require('../utils/dateUtils');

const alertsFilePath = path.join(__dirname, '../data/alerts.json');

const watchAlertFile = (socket) => {
  fs.readFile(alertsFilePath, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading alerts:', err);
      return;
    }
    socket.emit('alertUpdate', JSON.parse(data));
  });

  chokidar.watch(alertsFilePath).on('change', () => {
    console.log('File change detected');
    updateDatabaseFromFile();
  });
};

const updateDatabaseFromFile = async () => {
  try {
    const data = await fs.promises.readFile(alertsFilePath, 'utf8');
    const alerts = JSON.parse(data);

    const bulkOps = alerts.map(alert => ({
      updateOne: {
        filter: { id: alert.id },
        update: {
          ...alert,
          time: parseDate(alert.time)
        },
        upsert: true
      }
    }));

    await Alert.bulkWrite(bulkOps);
    const io = require('./socketService').getIO();
    io.emit('alertUpdate', alerts);
    console.log('Data imported/updated successfully');
  } catch (error) {
    console.error('Data import/update error:', error);
  }
};

module.exports = { watchAlertFile, updateDatabaseFromFile };