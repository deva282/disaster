const { transporter } = require('../config/email');

const sendAlertEmail = async (alertData) => {
  const mailOptions = {
    from: process.env.GMAIL_USER,
    to: 'sanketmule777@gmail.com', // Replace with actual NDRF center's email
    subject: `CRITICAL ALERT: ${alertData.type.toUpperCase()} in ${alertData.location} - Immediate Action Required`,
    html: generateAlertEmailTemplate(alertData)
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('Alert email sent successfully');
  } catch (error) {
    console.error('Error sending alert email:', error);
    throw error;
  }
};

const generateAlertEmailTemplate = (alertData) => {
  return `<!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Critical Disaster Alert</title>
  </head>
  <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
      <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f8f8f8; border-radius: 10px; overflow: hidden; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
          <tr>
              <td style="padding: 20px; background-color: #d9534f; color: white; text-align: center;">
                  <h1 style="margin: 0; font-size: 28px; text-transform: uppercase; letter-spacing: 2px;">⚠️ Critical Alert ⚠️</h1>
              </td>
          </tr>
          <tr>
              <td style="padding: 20px; background-color: #fff;">
                  <h2 style="color: #d9534f; margin-top: 0; font-size: 24px; text-align: center; border-bottom: 2px solid #d9534f; padding-bottom: 10px;">${alertData.type} Disaster in ${alertData.location}</h2>
                  <p style="font-size: 16px; text-align: center; font-weight: bold;">A critical situation has been reported. Immediate action required.</p>
                  <table width="100%" style="border-collapse: separate; border-spacing: 0 10px; margin-bottom: 20px;">
                      <tr>
                          <td style="padding: 15px; background-color: #f1f1f1; border-radius: 5px; font-weight: bold; width: 40%;">Disaster Type:</td>
                          <td style="padding: 15px; background-color: #e9ecef; border-radius: 5px;">${alertData.type}</td>
                      </tr>
                      <tr>
                          <td style="padding: 15px; background-color: #f1f1f1; border-radius: 5px; font-weight: bold;">Location:</td>
                          <td style="padding: 15px; background-color: #e9ecef; border-radius: 5px;">${alertData.location}</td>
                      </tr>
                      <tr>
                          <td style="padding: 15px; background-color: #f1f1f1; border-radius: 5px; font-weight: bold;">Severity:</td>
                          <td style="padding: 15px; border-radius: 5px; font-weight: bold; color: white; background-color: ${
                              alertData.severity === 'High' ? '#d9534f' :
                              alertData.severity === 'Medium' ? '#f0ad4e' : '#5bc0de'
                          };">${alertData.severity}</td>
                      </tr>
                      <tr>
                          <td style="padding: 15px; background-color: #f1f1f1; border-radius: 5px; font-weight: bold;">Affected People:</td>
                          <td style="padding: 15px; background-color: #e9ecef; border-radius: 5px;">${alertData.affected}</td>
                      </tr>
                  </table>
                  <div style="background-color: #d9534f; color: white; padding: 15px; border-radius: 5px; margin-top: 20px; text-align: center;">
                      <h3 style="margin-top: 0; margin-bottom: 10px;">Required Actions:</h3>
                      <ul style="list-style-type: none; padding: 0; margin: 0;">
                          <li style="margin-bottom: 5px;">✔️ Coordinate with local authorities</li>
                          <li style="margin-bottom: 5px;">✔️ Dispatch emergency response teams</li>
                          <li style="margin-bottom: 5px;">✔️ Activate evacuation protocols if necessary</li>
                          <li>✔️ Prepare medical and relief supplies</li>
                      </ul>
                  </div>
                  <div style="background-color: #e8e8e8; padding: 15px; border-radius: 5px; margin-top: 20px;">
                      <p style="margin: 0; font-style: italic; text-align: center;">This is an automated alert from the NDRF Disaster Management System. For more information or to report updates, please contact the disaster management team immediately.</p>
                  </div>
              </td>
          </tr>
          <tr>
              <td style="padding: 20px; background-color: #343a40; text-align: center; color: white;">
                  <p style="margin: 0; font-size: 16px; font-weight: bold;">NDRF Disaster Management System</p>
                  <p style="margin: 5px 0 0; font-size: 14px;">Emergency Hotline: <a href="tel:+911234567890" style="color: #ffffff;">+91 1234567890</a></p>
                  <div style="margin-top: 10px;">
                      <a href="#" style="color: white; text-decoration: none; margin: 0 10px;">Website</a> |
                      <a href="#" style="color: white; text-decoration: none; margin: 0 10px;">Twitter</a> |
                      <a href="#" style="color: white; text-decoration: none; margin: 0 10px;">Facebook</a>
                  </div>
              </td>
          </tr>
      </table>
  </body>
  </html>`;
};

module.exports = { sendAlertEmail };